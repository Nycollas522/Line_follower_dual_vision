#pragma once

#include <Arduino.h>

namespace Config {

constexpr char NAME[] = "ESP32S3_OMNI_LINE";
constexpr uint8_t N = 4;

enum Wheel : uint8_t {
  FL = 0,
  FR = 1,
  RL = 2,
  RR = 3,
};

constexpr uint8_t IN1[N] = {5, 39, 8, 47};   //5, 39, 8, 47
constexpr uint8_t IN2[N] = {4, 40, 9, 16};   //4, 40, 9, 16
constexpr uint8_t ENCA[N] = {6, 42, 11, 21};  //6, 42, 11, 21
constexpr uint8_t ENCB[N] = {7, 41, 10, 18};   //7, 41, 10, 18
constexpr int8_t MOTOR_SIGN[N] = {1, 1, 1, 1};
constexpr int8_t ENC_SIGN[N] = {1, 1, 1, 1};

constexpr uint8_t BTN1 = 12;
constexpr uint8_t BTN2 = 14;
constexpr uint8_t SERVO = 13;
constexpr uint8_t BATT = 15;
constexpr uint8_t BUZZER = 45;
constexpr uint8_t RGB = 48;

constexpr uint8_t SDA = 1;
constexpr uint8_t SCL = 2;
constexpr uint8_t MPU_ADDR = 0x68;
constexpr uint8_t OLED_ADDR = 0x3C;

constexpr uint32_t I2C_HZ = 400000;
constexpr uint32_t CONTROL_US = 10000;
constexpr uint32_t TELEMETRY_MS = 200;
constexpr uint32_t OLED_MS = 500;
constexpr uint32_t CMD_TIMEOUT_MS = 200;

constexpr uint32_t MOTOR_PWM_HZ = 20000;
constexpr uint8_t MOTOR_PWM_BITS = 8;
constexpr int PWM_MAX = 255;
constexpr int PWM_LIMIT_DEFAULT = 180;
constexpr int STATIC_PWM_DEFAULT = 100;

constexpr float WHEEL_D_M = 0.078f;
constexpr float WHEEL_C = PI * WHEEL_D_M;
constexpr float TICKS_REV_DEFAULT = 330.0f;
constexpr float HALF_L = 0.105f;
constexpr float HALF_W = 0.090f;
constexpr float K = HALF_L + HALF_W;

constexpr float MAX_WHEEL_MPS = 0.70f;
constexpr float MAX_WZ_ACCEL = 6.0f;
constexpr float KP_DEFAULT = 120.0f;
constexpr float KI_DEFAULT = 100.0f;
constexpr float KD_DEFAULT = 5.0f;
constexpr float I_LIMIT = 1.2f;

constexpr float YAW_ENCODER_WEIGHT = 0.15f;
constexpr float ACCEL_ALPHA = 0.20f;

constexpr float R1 = 100000.0f;
constexpr float R2 = 33000.0f;
constexpr float DIV_RATIO = (R1 + R2) / R2;
constexpr float LOW_BATT = 10.0f;
constexpr float CRIT_BATT = 9.5f;
}