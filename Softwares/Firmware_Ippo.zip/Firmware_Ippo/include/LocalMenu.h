#pragma once

#include <Adafruit_SSD1306.h>

#include "Settings.h"
#include "RobotTypes.h"

enum class MenuAction : uint8_t {
  NONE,
  STOP,
  RESET_ODOM,
  RESET_ENCODERS,
  CAL_IMU,
  SAVE,
};

class LocalMenu {
 public:
  bool begin();
  MenuAction update(Settings& cfg);
  void draw(
    const BatteryState& battery,
    const WheelState& wheels,
    const Odom& odometry,
    const Settings& cfg,
    bool ros
  );

  bool editing() const { return editingValue; }
  bool inTest() const {
    return screen == Screen::TEST_BATTERY ||
           screen == Screen::TEST_SERVO ||
           screen == Screen::TEST_MOTORS ||
           screen == Screen::TEST_ENCODERS;
  }
  bool motorTest() const { return screen == Screen::TEST_MOTORS; }
  bool servoTest() const { return screen == Screen::TEST_SERVO; }
  int motorTestPwm() const { return motorPwm; }
  int servoTestAngle() const { return servoAngle; }
  enum class Screen : uint8_t {
    STATUS,
    HOME,
    CONFIG_LIST,
    TEST_LIST,
    TEST_BATTERY,
    TEST_SERVO,
    TEST_MOTORS,
    TEST_ENCODERS,
  };

  Adafruit_SSD1306 display{128, 64, &Wire, -1};
  Screen screen = Screen::STATUS;
  uint8_t homeTab = 0;
  uint8_t configIndex = 0;
  uint8_t testIndex = 0;
  uint8_t motorIndex = 0;
  bool editingValue = false;
  uint32_t button1Down = 0;
  uint32_t button2Down = 0;
  uint32_t lastDraw = 0;
  uint32_t transitionStart = 0;
  bool previousButton1 = true;
  bool previousButton2 = true;
  bool ready = false;
  Screen drawnScreen = Screen::HOME;
  int motorPwm = 0;
  int servoAngle = 90;

 private:
  void changeConfig(Settings& cfg, int direction);
  void drawHome(bool ros);
  void drawStatus(
    const BatteryState& battery,
    const Odom& odometry,
    bool ros
  );
  void drawConfigList(const Settings& cfg);
  void drawTestList();
  void drawTestScreen(
    const BatteryState& battery,
    const WheelState& wheels,
    const Odom& odometry
  );
  void printFrame(const char* title, const char* value, const char* help);
};