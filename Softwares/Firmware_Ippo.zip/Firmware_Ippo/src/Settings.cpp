#include "Settings.h"

#include <Preferences.h>

#include "Config.h"

void Settings::defaults() {
  d = {
    Config::KP_DEFAULT,
    Config::KI_DEFAULT,
    Config::KD_DEFAULT,
    Config::TICKS_REV_DEFAULT,
    1.0f,
    Config::MAX_WHEEL_MPS,
    Config::YAW_ENCODER_WEIGHT,
    Config::STATIC_PWM_DEFAULT,
    Config::PWM_LIMIT_DEFAULT
  };
  dirty = true;
}

void Settings::begin() {
  load();
}

void Settings::load() {
  Preferences p;
  if (!p.begin("robot", true)) {
    defaults();
    return;
  }

  if (!p.getBool("ok", false)) {
    p.end();
    defaults();
    save();
    return;
  }

  d.kp = p.getFloat("kp", Config::KP_DEFAULT);
  d.ki = p.getFloat("ki", Config::KI_DEFAULT);
  d.kd = p.getFloat("kd", Config::KD_DEFAULT);
  d.ticksRev = p.getFloat("ticks", Config::TICKS_REV_DEFAULT);
  d.battCal = p.getFloat("bcal", 1.0f);
  d.maxWheelMps = p.getFloat("maxmps", Config::MAX_WHEEL_MPS);
  d.yawEncoderWeight = p.getFloat(
    "yawweight",
    Config::YAW_ENCODER_WEIGHT
  );
  d.staticPwm = p.getInt("stat", Config::STATIC_PWM_DEFAULT);
  d.pwmLimit = p.getInt("limit", Config::PWM_LIMIT_DEFAULT);
  p.end();
  dirty = false;
}

bool Settings::save() {
  Preferences p;
  if (!p.begin("robot", false)) {
    return false;
  }

  p.putBool("ok", true);
  p.putFloat("kp", d.kp);
  p.putFloat("ki", d.ki);
  p.putFloat("kd", d.kd);
  p.putFloat("ticks", d.ticksRev);
  p.putFloat("bcal", d.battCal);
  p.putFloat("maxmps", d.maxWheelMps);
  p.putFloat("yawweight", d.yawEncoderWeight);
  p.putInt("stat", d.staticPwm);
  p.putInt("limit", d.pwmLimit);
  p.end();
  dirty = false;
  return true;
}