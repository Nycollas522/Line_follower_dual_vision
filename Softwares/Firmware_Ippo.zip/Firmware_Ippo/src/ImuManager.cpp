#include "ImuManager.h"

#include "Config.h"

bool ImuManager::begin(TwoWire& w) {
  s.ready = m.begin(Config::MPU_ADDR, &w);
  if (s.ready) {
    m.setAccelerometerRange(MPU6050_RANGE_4_G);
    m.setGyroRange(MPU6050_RANGE_500_DEG);
    m.setFilterBandwidth(MPU6050_BAND_21_HZ);
  }
  return s.ready;
}

void ImuManager::update() {
  if (!s.ready) {
    return;
  }

  sensors_event_t a, g, t;
  m.getEvent(&a, &g, &t);
  s.ax += Config::ACCEL_ALPHA * (a.acceleration.x - s.ax);
  s.ay += Config::ACCEL_ALPHA * (a.acceleration.y - s.ay);
  s.az += Config::ACCEL_ALPHA * (a.acceleration.z - s.az);
  s.gx = g.gyro.x;
  s.gy = g.gyro.y;
  s.gz = g.gyro.z - bias;
  s.bias = bias;
}

void ImuManager::calibrate() {
  if (!s.ready) {
    return;
  }

  float z = 0;
  sensors_event_t a, g, t;
  for (int i = 0; i < 500; i++) {
    m.getEvent(&a, &g, &t);
    z += g.gyro.z;
    delay(3);
  }
  bias = z / 500.0f;
}