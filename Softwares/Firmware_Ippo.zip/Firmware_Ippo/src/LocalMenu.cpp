#include "LocalMenu.h"

#include "Config.h"

namespace {
constexpr uint8_t CONFIG_COUNT = 10;
constexpr uint8_t TEST_COUNT = 4;
constexpr uint32_t LONG_PRESS_MS = 700;
}

bool LocalMenu::begin() {
  ready = display.begin(SSD1306_SWITCHCAPVCC, Config::OLED_ADDR);
  if (!ready) ready = display.begin(SSD1306_SWITCHCAPVCC, 0x3D);
  Serial.printf("OLED,%s\n", ready ? "READY" : "NOT_FOUND");
  if (ready) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println("Booting...");
    display.display();
  }
  return ready;
}

void LocalMenu::changeConfig(Settings& cfg, int direction) {
  auto& value = cfg.edit();
  switch (configIndex) {
    case 0: value.kp = constrain(value.kp + direction * 5.0f, 0.0f, 500.0f); break;
    case 1: value.ki = constrain(value.ki + direction * 5.0f, 0.0f, 500.0f); break;
    case 2: value.kd = constrain(value.kd + direction * 0.5f, 0.0f, 100.0f); break;
    case 3: value.staticPwm = constrain(value.staticPwm + direction * 5, 0, 255); break;
    case 4: value.pwmLimit = constrain(value.pwmLimit + direction * 5, 0, 255); break;
    case 5: value.ticksRev = constrain(value.ticksRev + direction, 1.0f, 5000.0f); break;
    case 6: value.battCal = constrain(value.battCal + direction * 0.01f, 0.5f, 1.5f); break;
    case 7: value.maxWheelMps = constrain(value.maxWheelMps + direction * 0.05f, 0.1f, 2.0f); break;
    case 8: value.yawEncoderWeight = constrain(value.yawEncoderWeight + direction * 0.05f, 0.0f, 1.0f); break;
    default: break;
  }
}

MenuAction LocalMenu::update(Settings& cfg) {
  const bool button1 = digitalRead(Config::BTN1);
  const bool button2 = digitalRead(Config::BTN2);
  const uint32_t now = millis();
  MenuAction action = MenuAction::NONE;

  if (previousButton1 && !button1) button1Down = now;
  if (previousButton2 && !button2) button2Down = now;

  if (!previousButton1 && button1) {
    if (now - button1Down >= LONG_PRESS_MS) {
      action = MenuAction::STOP;
      screen = Screen::HOME;
      editingValue = false;
      motorPwm = 0;
    } else if (screen == Screen::STATUS) {
      screen = Screen::HOME;
    } else if (screen == Screen::HOME) {
      homeTab = !homeTab;
    } else if (screen == Screen::CONFIG_LIST) {
      if (editingValue) changeConfig(cfg, 1);
      else configIndex = (configIndex + 1) % CONFIG_COUNT;
    } else if (screen == Screen::TEST_LIST) {
      testIndex = (testIndex + 1) % TEST_COUNT;
    } else if (screen == Screen::TEST_SERVO) {
      servoAngle += 10;
      if (servoAngle > 180) servoAngle = 0;
    } else if (screen == Screen::TEST_MOTORS) {
      motorPwm += 50;
      if (motorPwm > Config::PWM_MAX) motorPwm = -Config::PWM_MAX;
    }
  }

  if (!previousButton2 && button2) {
    if (now - button2Down >= LONG_PRESS_MS) {
      if (screen == Screen::CONFIG_LIST && editingValue) {
        editingValue = false;
        action = MenuAction::NONE;
      } else {
        action = MenuAction::SAVE;
        screen = Screen::HOME;
        editingValue = false;
        motorPwm = 0;
      }
    } else if (screen == Screen::STATUS) {
      screen = Screen::HOME;
    } else if (screen == Screen::HOME) {
      screen = homeTab == 0 ? Screen::CONFIG_LIST : Screen::TEST_LIST;
    } else if (screen == Screen::CONFIG_LIST) {
      if (editingValue) changeConfig(cfg, -1);
      else if (configIndex == 9) action = MenuAction::SAVE;
      else editingValue = true;
    } else if (screen == Screen::TEST_LIST) {
      if (testIndex == 0) screen = Screen::TEST_BATTERY;
      else if (testIndex == 1) screen = Screen::TEST_SERVO;
      else if (testIndex == 2) screen = Screen::TEST_MOTORS;
      else screen = Screen::TEST_ENCODERS;
      motorPwm = 0;
    } else {
      screen = Screen::TEST_LIST;
      motorPwm = 0;
    }
  }

  previousButton1 = button1;
  previousButton2 = button2;
  return action;
}

void LocalMenu::printFrame(const char* title, const char* value, const char* help) {
  const uint32_t elapsed = millis() - transitionStart;
  const int offset = elapsed < 150 ? 64 - (elapsed * 64 / 150) : 0;
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, offset);
  display.println(title);
  display.println();
  display.println(value);
  display.setCursor(0, 48 + offset);
  display.println(help);
  display.display();
}

void LocalMenu::drawHome(bool ros) {
  const uint32_t elapsed = millis() - transitionStart;
  const int offset = elapsed < 150 ? 64 - (elapsed * 64 / 150) : 0;
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, offset);
  display.println("MENU PRINCIPAL");
  display.setCursor(0, 20 + offset);
  display.print(homeTab == 0 ? "> " : "  ");
  display.println("CONFIGURACOES");
  display.print(homeTab == 1 ? "> " : "  ");
  display.println("TESTES");
  display.setCursor(0, 52 + offset);
  display.println(ros ? "B1 troca  B2 entra" : "B1 troca  B2 entra");
  display.display();
}

void LocalMenu::drawStatus(
  const BatteryState& battery,
  const Odom& odometry,
  bool ros
) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("STATUS DO ROBO");
  char line[24];
  snprintf(line, sizeof line, "BAT %.2fV %s", battery.voltage, ros ? "OK" : "--");
  display.println(line);
  snprintf(line, sizeof line, "VEL %.2f %.2f", odometry.vx, odometry.vy);
  display.println(line);
  snprintf(line, sizeof line, "GIRO %.2f", odometry.wz);
  display.println(line);
  display.setCursor(0, 52);
  display.println("B1 ou B2: MENU");
  display.display();
}

void LocalMenu::drawConfigList(const Settings& cfg) {
  const char* names[CONFIG_COUNT] = {"KP", "KI", "KD", "PWM MIN", "PWM LIMITE", "TICKS/VOLTA", "CAL BATERIA", "MAX VELOCIDADE", "PESO YAW", "SALVAR"};
  const uint32_t elapsed = millis() - transitionStart;
  const int offset = elapsed < 150 ? 64 - (elapsed * 64 / 150) : 0;
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, offset);
  display.printf("CONFIG %u/%u", configIndex + 1, CONFIG_COUNT);
  for (uint8_t row = 0; row < 3; row++) {
    const uint8_t index = (configIndex + row + CONFIG_COUNT - 1) % CONFIG_COUNT;
    display.setCursor(0, 12 + row * 12 + offset);
    if (row == 1) {
      if (configIndex == 0) display.printf("> KP %.1f", cfg.get().kp);
      else if (configIndex == 1) display.printf("> KI %.1f", cfg.get().ki);
      else if (configIndex == 2) display.printf("> KD %.1f", cfg.get().kd);
      else if (configIndex == 3) display.printf("> PWM MIN %d", cfg.get().staticPwm);
      else if (configIndex == 4) display.printf("> PWM LIM %d", cfg.get().pwmLimit);
      else if (configIndex == 5) display.printf("> TICKS %.0f", cfg.get().ticksRev);
      else if (configIndex == 6) display.printf("> CAL %.2f", cfg.get().battCal);
      else if (configIndex == 7) display.printf("> MAX %.2f", cfg.get().maxWheelMps);
      else if (configIndex == 8) display.printf("> YAW %.2f", cfg.get().yawEncoderWeight);
      else display.print("> SALVAR");
    } else {
      display.printf("  %s", names[index]);
    }
  }
  display.setCursor(0, 48 + offset);
  if (editingValue) display.println("B1 +  B2 -  B2 longo sai");
  else display.println("B1 desce  B2 seleciona");
  display.display();
}

void LocalMenu::drawTestList() {
  const char* tests[TEST_COUNT] = {"BATERIA", "SERVO", "4 MOTORES", "ENCODERS"};
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.printf("TESTES %u/%u", testIndex + 1, TEST_COUNT);
  for (uint8_t row = 0; row < TEST_COUNT; row++) {
    display.setCursor(0, 12 + row * 10);
    display.printf("%c %s", row == testIndex ? '>' : ' ', tests[row]);
  }
  display.setCursor(0, 52);
  display.println("B1 desce  B2 abre");
  display.display();
}

void LocalMenu::drawTestScreen(const BatteryState& battery, const WheelState& wheels, const Odom& odometry) {
  char value[32];
  if (screen == Screen::TEST_BATTERY) {
    snprintf(value, sizeof value, "%.2f V %s", battery.voltage, battery.critical ? "CRITICA" : battery.low ? "BAIXA" : "OK");
    printFrame("TESTE BATERIA", value, "B2 voltar");
  } else if (screen == Screen::TEST_SERVO) {
    snprintf(value, sizeof value, "ANGULO %d graus", servoAngle);
    printFrame("TESTE SERVO", value, "B1 move  B2 voltar");
  } else if (screen == Screen::TEST_MOTORS) {
    snprintf(value, sizeof value, "TODOS PWM %d", motorPwm);
    printFrame("TESTE 4 MOTORES", value, "B1 avanca  B2 voltar");
  } else {
    snprintf(value, sizeof value, "%ld %ld %ld %ld", (long) wheels.count[0], (long) wheels.count[1], (long) wheels.count[2], (long) wheels.count[3]);
    (void) odometry;
    printFrame("TESTE ENCODERS", value, "B2 voltar");
  }
}

void LocalMenu::draw(const BatteryState& battery, const WheelState& wheels, const Odom& odometry, const Settings& cfg, bool ros) {
  if (!ready || millis() - lastDraw < Config::OLED_MS) return;
  lastDraw = millis();
  if (screen != drawnScreen) {
    drawnScreen = screen;
    transitionStart = millis();
  }
  if (screen == Screen::STATUS) drawStatus(battery, odometry, ros);
  else if (screen == Screen::HOME) drawHome(ros);
  else if (screen == Screen::CONFIG_LIST) drawConfigList(cfg);
  else if (screen == Screen::TEST_LIST) drawTestList();
  else drawTestScreen(battery, wheels, odometry);
}
