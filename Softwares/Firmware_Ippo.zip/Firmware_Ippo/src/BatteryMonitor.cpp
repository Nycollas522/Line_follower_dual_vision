#include "BatteryMonitor.h"

#include "Config.h"

void BatteryMonitor::begin() {
  analogReadResolution(12);
  analogSetPinAttenuation(Config::BATT, ADC_11db);
}

void BatteryMonitor::update(float cal) {
  if (millis() - last < 500) {
    return;
  }

  last = millis();
  s.voltage = (analogReadMilliVolts(Config::BATT) / 1000.0f) *
              Config::DIV_RATIO * cal;
  s.low = s.voltage < Config::LOW_BATT;
  s.critical = s.voltage < Config::CRIT_BATT;
}