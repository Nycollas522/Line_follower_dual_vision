#pragma once

#include <Arduino.h>

#include "Config.h"

struct Twist {
  float vx;
  float vy;
  float wz;
};

struct WheelState {
  int32_t count[Config::N];
  float speed[Config::N];
  float target[Config::N];
  int pwm[Config::N];
};

struct Odom {
  float x;
  float y;
  float yaw;
  float vx;
  float vy;
  float wz;
};

struct ImuState {
  bool ready;
  float ax;
  float ay;
  float az;
  float gx;
  float gy;
  float gz;
  float bias;
};

struct BatteryState {
  float voltage;
  bool low;
  bool critical;
};