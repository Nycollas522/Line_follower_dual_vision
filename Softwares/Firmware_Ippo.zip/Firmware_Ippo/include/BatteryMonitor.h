#pragma once

#include "RobotTypes.h"

class BatteryMonitor {
 public:
  void begin();
  void update(float cal);
  const BatteryState& state() const { return s; }

 private:
  BatteryState s;
  uint32_t last = 0;
};