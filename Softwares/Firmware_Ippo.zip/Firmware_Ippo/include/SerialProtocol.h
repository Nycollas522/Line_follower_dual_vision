#pragma once

#include <Arduino.h>

class SerialProtocol {
 public:
  enum Type : uint8_t {
    NONE,
    TWIST,
    STOP,
    SERVO,
    PID,
    STATUS,
    SAVE,
  };

  struct Cmd {
    Type type = NONE;
    float a = 0.0f;
    float b = 0.0f;
    float c = 0.0f;
  };

  bool poll(Cmd& x);

 private:
  char buf[96] = {};
  uint8_t n = 0;
};