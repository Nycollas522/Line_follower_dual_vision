#include "EncoderManager.h"

constexpr pcnt_unit_t EncoderManager::units[Config::N];

void EncoderManager::begin() {
  for (uint8_t i = 0; i < Config::N; i++) {
    pinMode(Config::ENCA[i], INPUT_PULLUP);
    pinMode(Config::ENCB[i], INPUT_PULLUP);

    pcnt_config_t config = {};
    config.pulse_gpio_num = Config::ENCA[i];
    config.ctrl_gpio_num = Config::ENCB[i];
    config.unit = units[i];
    config.channel = PCNT_CHANNEL_0;
    config.pos_mode = PCNT_COUNT_INC;
    config.neg_mode = PCNT_COUNT_DIS;
    config.lctrl_mode = PCNT_MODE_REVERSE;
    config.hctrl_mode = PCNT_MODE_KEEP;
    config.counter_h_lim = 32767;
    config.counter_l_lim = -32768;

    ESP_ERROR_CHECK(pcnt_unit_config(&config));
    ESP_ERROR_CHECK(pcnt_set_filter_value(units[i], 1000));
    ESP_ERROR_CHECK(pcnt_filter_enable(units[i]));
    ESP_ERROR_CHECK(pcnt_counter_pause(units[i]));
    ESP_ERROR_CHECK(pcnt_counter_clear(units[i]));
    ESP_ERROR_CHECK(pcnt_counter_resume(units[i]));
  }
  reset();
}

void EncoderManager::reset() {
  portENTER_CRITICAL(&mux);
  for (uint8_t i = 0; i < Config::N; i++) {
    c[i] = 0;
    pcnt_counter_pause(units[i]);
    pcnt_counter_clear(units[i]);
    pcnt_counter_resume(units[i]);
  }
  portEXIT_CRITICAL(&mux);
}

void EncoderManager::read(int32_t v[Config::N]) {
  portENTER_CRITICAL(&mux);
  for (uint8_t i = 0; i < Config::N; i++) {
    int16_t count = 0;
    pcnt_get_counter_value(units[i], &count);
    c[i] += static_cast<int32_t>(count) * Config::ENC_SIGN[i];
    pcnt_counter_pause(units[i]);
    pcnt_counter_clear(units[i]);
    pcnt_counter_resume(units[i]);
    v[i] = c[i];
  }
  portEXIT_CRITICAL(&mux);
}