#pragma once

#include <Wire.h>
#include <Adafruit_MPU6050.h>

#include "RobotTypes.h"

class ImuManager {
 public:
  bool begin(TwoWire& w);
  void update();
  void calibrate();
  const ImuState& state() const { return s; }

 private:
  Adafruit_MPU6050 m;
  ImuState s;
  float bias = 0;
};