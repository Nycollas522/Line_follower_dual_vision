#include <Arduino.h>
#include <Wire.h>
#include <ESP32Servo.h>
#include "Config.h"
#include "RobotTypes.h"
#include "Settings.h"
#include "MotorDriver.h"
#include "EncoderManager.h"
#include "WheelPid.h"
#include "ImuManager.h"
#include "BatteryMonitor.h"
#include "Feedback.h"
#include "LocalMenu.h"
#include "SerialProtocol.h"

MotorDriver motor;
EncoderManager enc;
ImuManager imu;
BatteryMonitor batt;
Feedback fb;
LocalMenu menu;
SerialProtocol serial;
Settings cfg;
Servo servo;
WheelPid pid[Config::N];
WheelState ws;
Odom od;
Twist cmd;
float appliedYaw = 0.0f;
uint32_t lastControl = 0;
uint32_t lastCmd = 0;
uint32_t lastTel = 0;
float servoAngle = 0;
bool test = false;

float ticksPerMeter() {
  return cfg.get().ticksRev / Config::WHEEL_C;
}

void apply() {
  for (uint8_t i = 0; i < Config::N; i++) {
    pid[i].gains(cfg.get().kp, cfg.get().ki, cfg.get().kd);
  }
}

void stop() {
  cmd = {};
  appliedYaw = 0.0f;
  lastCmd = 0;
  test = false;
  motor.stop();
  for (auto& p : pid) {
    p.reset();
  }
  fb.set(LedState::STOPPED);
}

void odometry(float dt) {
  static int32_t prev[4] = {};
  float d[4];
  for (uint8_t i = 0; i < 4; i++) {
    d[i] = (ws.count[i] - prev[i]) / ticksPerMeter();
    prev[i] = ws.count[i];
    ws.speed[i] = d[i] / dt;
  }
  float dx = (d[0] + d[1] + d[2] + d[3]) * 0.25f;
  float dy = (-d[0] + d[1] + d[2] - d[3]) * 0.25f;
  float de = (-d[0] + d[1] - d[2] + d[3]) / (4 * Config::K);
  float dg = imu.state().gz * dt;
  float da = imu.state().ready
    ? (1 - cfg.get().yawEncoderWeight) * dg +
      cfg.get().yawEncoderWeight * de
    : de;
  float ym = od.yaw + da * 0.5f;
  od.x += cosf(ym) * dx - sinf(ym) * dy;
  od.y += sinf(ym) * dx + cosf(ym) * dy;
  od.yaw = atan2f(sinf(od.yaw + da), cosf(od.yaw + da));
  od.vx = (ws.speed[0] + ws.speed[1] + ws.speed[2] + ws.speed[3]) * 0.25f;
  od.vy = (-ws.speed[0] + ws.speed[1] + ws.speed[2] - ws.speed[3]) * 0.25f;
  od.wz = (-ws.speed[0] + ws.speed[1] - ws.speed[2] + ws.speed[3]) /
          (4 * Config::K);
}

void control(float dt) {
  enc.read(ws.count);
  imu.update();
  odometry(dt);

  if (millis() - lastCmd > Config::CMD_TIMEOUT_MS) {
    cmd = {};
  }

  const float maxYawStep = Config::MAX_WZ_ACCEL * dt;
  appliedYaw = constrain(
    cmd.vy,
    appliedYaw - maxYawStep,
    appliedYaw + maxYawStep
  );

  float k = Config::K;
  const float lateral = cmd.wz;
  const float yaw = appliedYaw;

  ws.target[0] = cmd.vx - lateral - k * yaw;
  ws.target[1] = cmd.vx + lateral + k * yaw;
  ws.target[2] = cmd.vx + lateral - k * yaw;
  ws.target[3] = cmd.vx - lateral + k * yaw;

  for (uint8_t i = 0; i < 4; i++) {
    ws.target[i] = constrain(
      ws.target[i],
      -cfg.get().maxWheelMps,
      cfg.get().maxWheelMps
    );

    if (fabsf(ws.target[i]) < 0.002f) {
      pid[i].reset();
      motor.set(i, 0);
    } else {
      float ff = ws.target[i] > 0
        ? cfg.get().staticPwm
        : -cfg.get().staticPwm;
      int u = lroundf(constrain(
        ff + pid[i].update(ws.target[i], ws.speed[i], dt),
        -float(cfg.get().pwmLimit),
        float(cfg.get().pwmLimit)
      ));
      if (u != 0 && abs(u) < 45) {
        u = u > 0 ? 45 : -45;
      }
      motor.set(i, u);
    }
    ws.pwm[i] = motor.last(i);
  }
}

void telemetry() {
  if (millis() - lastTel < Config::TELEMETRY_MS) {
    return;
  }
  lastTel = millis();

  Serial.printf(
    "ENC,%ld,%ld,%ld,%ld\n",
    (long) ws.count[0],
    (long) ws.count[1],
    (long) ws.count[2],
    (long) ws.count[3]
  );

  Serial.printf(
    "ODOM,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f\n",
    od.x, od.y, od.yaw, od.vx, od.vy, od.wz
  );

  Serial.printf(
    "WHEEL,%.4f,%.4f,%.4f,%.4f\n",
    ws.speed[0], ws.speed[1], ws.speed[2], ws.speed[3]
  );

  Serial.printf(
    "TARGET,%.4f,%.4f,%.4f,%.4f\n",
    ws.target[0], ws.target[1], ws.target[2], ws.target[3]
  );

  Serial.printf(
    "PWM,%d,%d,%d,%d\n",
    ws.pwm[0], ws.pwm[1], ws.pwm[2], ws.pwm[3]
  );

  if (imu.state().ready) {
    Serial.printf(
      "IMU,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n",
      imu.state().ax,
      imu.state().ay,
      imu.state().az,
      imu.state().gx,
      imu.state().gy,
      imu.state().gz
    );
  }

  Serial.printf("SERVO_STATE,%.2f\n", servoAngle);
  Serial.printf("BATT,%.2f\n", batt.state().voltage);
}

void setup() {
  Serial.begin(115200);
  pinMode(Config::BTN1, INPUT_PULLUP);
  pinMode(Config::BTN2, INPUT_PULLUP);
  cfg.begin();
  apply();

  servo.setPeriodHertz(50);
  servo.attach(Config::SERVO, 500, 2400);
  servo.write(90);

  motor.begin();
  enc.begin();
  Wire.begin(Config::SDA, Config::SCL);
  Wire.setClock(Config::I2C_HZ);
  imu.begin(Wire);
  if (imu.state().ready) {
    imu.calibrate();
  }
  batt.begin();
  fb.begin();
  menu.begin();
  lastControl = micros();
  Serial.println("READY,ESP32S3_OMNI_MENU");
}

void loop() {
  SerialProtocol::Cmd s;
  while (serial.poll(s)) {
    if (s.type == SerialProtocol::TWIST) {
      // Nesta montagem, o giro fÃ­sico chega pelo segundo campo.
      cmd = {s.a, s.b, s.c};
      lastCmd = millis();
    } else if (s.type == SerialProtocol::STOP) {
      stop();
    } else if (s.type == SerialProtocol::SERVO) {
      servoAngle = constrain(s.a, -90.0f, 90.0f);
      servo.write(lroundf(servoAngle + 90));
    } else if (s.type == SerialProtocol::PID) {
      auto& x = cfg.edit();
      x.kp = s.a;
      x.ki = s.b;
      x.kd = s.c;
      apply();
    } else if (s.type == SerialProtocol::SAVE) {
      Serial.println(cfg.save() ? "OK,SAVED" : "ERROR,SAVE");
    } else if (s.type == SerialProtocol::STATUS) {
      Serial.printf(
        "STATUS,IMU_%s,OLED_%s\n",
        imu.state().ready ? "READY" : "NOT_FOUND",
        menu.inTest() ? "TEST" : "READY"
      );
    }
  }

  uint32_t now = micros();
  if (now - lastControl >= Config::CONTROL_US) {
    float dt = (now - lastControl) * 1e-6f;
    lastControl = now;
    if (dt < 0.1f) {
      if (menu.motorTest()) {
        for (uint8_t i = 0; i < Config::N; i++) {
          motor.set(i, menu.motorTestPwm());
        }
      } else if (menu.servoTest()) {
        servo.write(menu.servoTestAngle());
      } else {
        control(dt);
      }
    }
  }

  batt.update(cfg.get().battCal);
  MenuAction a = menu.update(cfg);
  if (a == MenuAction::STOP) {
    stop();
    servo.write(90);
  }
  if (a == MenuAction::RESET_ODOM) od = {};
  if (a == MenuAction::RESET_ENCODERS) enc.reset();
  if (a == MenuAction::CAL_IMU) {
    stop();
    imu.calibrate();
  }
  if (a == MenuAction::SAVE) {
    apply();
    fb.beep(2200, 90);
    Serial.println(cfg.save() ? "OK,SAVED" : "ERROR,SAVE");
  }

  if (menu.inTest() && !menu.motorTest() && !menu.servoTest()) {
    motor.stop();
  }

  bool ros = millis() - lastCmd < Config::CMD_TIMEOUT_MS;
  if (batt.state().critical) {
    fb.set(LedState::BATTERY_CRITICAL);
  } else if (batt.state().low) {
    fb.set(LedState::BATTERY_LOW);
  } else if (menu.editing()) {
    fb.set(LedState::MENU);
  } else {
    fb.set(
      ros
        ? LedState::RUN
        : LedState::IDLE
    );
  }

  fb.update();
  menu.draw(batt.state(), ws, od, cfg, ros);
  telemetry();
}