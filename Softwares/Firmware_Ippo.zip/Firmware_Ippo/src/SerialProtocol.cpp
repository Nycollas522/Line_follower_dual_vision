#include "SerialProtocol.h"

#include <cstring>

bool SerialProtocol::poll(Cmd& x) {
  x = {};

  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (!n) {
        continue;
      }

      buf[n] = 0;
      n = 0;

      if (!strcmp(buf, "STOP")) {
        x.type = STOP;
        return true;
      }
      if (!strcmp(buf, "STATUS")) {
        x.type = STATUS;
        return true;
      }
      if (!strcmp(buf, "SAVE_SETTINGS")) {
        x.type = SAVE;
        return true;
      }
      if (sscanf(buf, "TWIST,%f,%f,%f", &x.a, &x.b, &x.c) == 3) {
        x.type = TWIST;
        return true;
      }
      if (sscanf(buf, "SERVO,%f", &x.a) == 1) {
        x.type = SERVO;
        return true;
      }
      if (sscanf(buf, "SET_PID,%f,%f,%f", &x.a, &x.b, &x.c) == 3) {
        x.type = PID;
        return true;
      }
      return false;
    }

    if (n < sizeof(buf) - 1) {
      buf[n++] = c;
    }
  }

  return false;
}